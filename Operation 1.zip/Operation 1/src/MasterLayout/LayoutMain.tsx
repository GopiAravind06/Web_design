import React, { useState } from "react";
import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
} from "@ant-design/icons";
import { Button, Layout, Menu, theme } from "antd";
import { Outlet, useNavigate } from "react-router-dom";

const { Header, Sider, Content } = Layout;

const LayoutMain: React.FC = () => {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  return (
    <Layout>
      <Sider
        style={{ backgroundColor: "black" }}
        trigger={null}
        collapsible
        collapsed={collapsed}
      >
        <div className="demo-logo-vertical" />
        <h1 style={{ color: "white", padding: "20px", marginLeft: "40px" }}>
          {!collapsed ? "CRUD" : "C"}
        </h1>
        <Menu
          style={{ backgroundColor: "black" }}
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["Employee"]}
          onClick={({ key }: any) => {
            navigate(key);
          }}
          items={[
            {
              key: "/Employee",
              icon: <UserOutlined />,
              label: "Employee",
            },
            {
              key: "/Details",
              icon: <UploadOutlined />,
              label: "Details",
            },
          ]}
        />

           <Menu
          style={{ backgroundColor: "black" , marginTop:"450px"}}
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["Employee"]}
          onClick={({ key }: any) => {
            navigate(key);
            sessionStorage.clear()
          }}
          items={[
            {
              key: "/Login",
              icon: <UserOutlined />,
              label: "Sign Out",
            }
          ]}
        />
      </Sider>
      <Layout>
        <Header style={{ padding: 0, background: colorBgContainer }}>
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{
              fontSize: "16px",
              width: 64,
              height: 64,
            }}
          />
        </Header>
        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            minHeight: 600,
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
          }}
        >
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default LayoutMain;
