import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

type FieldType = {
  username?: string;
  password?: string;
};

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [inputValue, setInputValue] = useState<FieldType>({
    username: "",
    password: "",
  });

  const handleChange = (result: any) => {
    const { id, value } = result;
    setInputValue((prev: any) => ({
      ...prev,
      [id]: value,
    }));
  };

  const onSave = () => {
    const { username }: any = inputValue;
    sessionStorage.setItem("username", username);
    navigate('/Employee')
  };
  return (
    <>
      <div className="container ">
        <div
          className="card login-body  mb-3"
          style={{ width: "25rem", height: "25rem" }}
        >
          <div className="card-body">
            <h5 className="card-title">Log In</h5>
            <form>
              <div className="login-content">
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">
                    User Name/Email
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="username"
                    aria-describedby="name"
                    value={inputValue.username}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                  <div id="emailHelp" className="form-text">
                    We'll never share your email with anyone else.
                  </div>
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">
                    Password
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    value={inputValue.password}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
                <button
                  type="submit"
                  className="btn btn-primary"
                  onClick={onSave}
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
