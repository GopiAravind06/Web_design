import {
  Flex,
  Space,
  Button,
  Table,
  Modal,
  Form,
  Input,
  Row,
  Col,
  message,
} from "antd";
import type { TableProps } from "antd";
import { useEffect, useState } from "react";
import { deleted, get, post, put } from "../Services/Services";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { toast, ToastContainer } from "react-toastify";

interface DataType {
  key: string;
  name: string;
  age: number;
  address: string;
  tags: string[];
}

interface inputProps {
  id: string;
  name: string;
  age: string;
  equalification: string;
  designation: string;
}
function Employee() {
  const [form] = Form.useForm();
  const [openModal, setOpenMoal] = useState(false);
  const [data, setData] = useState([]);
  const [rowSelected, setRowSelected] = useState<boolean>(false);
  const [inputValue, setInputValue] = useState<inputProps>({
    id: "",
    name: "",
    age: "",
    equalification: "",
    designation: "",
  });
  const handlechange = (result: any) => {
    const { value, id } = result;
    setInputValue((prev: any) => ({
      ...prev,
      [id]: value,
    }));
  };
  useEffect(() => {
    getAllList();
  }, []);
  const getAllList = () => {
    try {
      get("Employee")?.then((result: any) => {
        setData(result.data);
      });
    } catch (e) {
      console.log(e);
    }
  };

  const onReset = () => {
    setRowSelected(false);
    setInputValue({
      id: "",
      name: "",
      age: "",
      equalification: "",
      designation: "",
    });
    setOpenMoal(false);
  };

  const onSave = () => {
    if (validation()) {
      try {
        const endpoints = !rowSelected
          ? `Employee`
          : `Employee/${inputValue.id}`;
        const method = !rowSelected ? post : put;
        method(endpoints, inputValue)?.then((result: any) => {
          getAllList();
          message.success(
            rowSelected
              ? `Employee updated successfully`
              : `Employee added successfully`,
          );
          onReset();
        });
      } catch (e: any) {
        console.log(e);
      }
    }
  };
  const handleRowClick = (record: any) => {
    setOpenMoal(true);
    setRowSelected(true);
    get(`Employee/${record.id}`)?.then((result: any) => {
      setInputValue(result.data);
    });
  };
  const columns: TableProps<DataType>["columns"] = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      // render: (text) => <a>{text}</a>,
    },
    {
      title: "Age",
      dataIndex: "age",
      key: "age",
    },
    {
      title: "Equalification",
      dataIndex: "equalification",
      key: "equalification",
    },
    {
      title: "Designation",
      dataIndex: "designation",
      key: "designation",
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Space size="medium">
          <EditOutlined
            onClick={() => {
              handleRowClick(record);
            }}
          />
          <DeleteOutlined  onClick={()=>{onDelete(record)}}/>
        </Space>
      ),
    },
  ];
  const validation = () => {
    if (inputValue.name?.trim() === "") {
      message.error("Please Enter Name!");
      return false;
    }
    if (inputValue?.age.trim() === "") {
      message.error("Please Enter Age!");
      return false;
    }
    if (inputValue.equalification?.trim() === "") {
      message.error("Please Enter equalification!");
      return false;
    }
    if (inputValue.designation?.trim() === "") {
      message.error("Please Enter designation!");
      return false;
    }
    return true;
  };

  const onDelete = (record: any) => {
    deleted(`Employee/${record.id}`, record)?.then((result: any) => {
      message.success(`Employee deleted successfully`);
      getAllList()
    });
  };

  return (
    <div className="container">
      <ToastContainer />
      <div className="content-head">
        <h2>Employee</h2>
        <div>
          <Button type="primary" onClick={() => setOpenMoal(true)}>
            Add Employee
          </Button>
        </div>
      </div>
      <div className="content-body">
        <Table<DataType> columns={columns} dataSource={data} />
      </div>

      <Flex vertical gap="medium" align="flex-start">
        <Modal
          title="Employee"
          centered
          open={openModal}
          onOk={() => {
            onSave();
          }}
          onCancel={() => {
            onReset();
          }}
          width={{
            xs: "90%",
            sm: "80%",
            md: "70%",
            lg: "60%",
            xl: "50%",
            xxl: "40%",
          }}
        >
          <Row gutter={16}>
            <Col className="gutter-row" span={12}>
              <Form.Item
                label="Employee Name"
                rules={[{ required: true, message: "Please Enter Name!" }]}
              >
                <Input
                  id="name"
                  value={inputValue.name || ""}
                  onChange={(e) => handlechange(e.target)}
                />
              </Form.Item>
            </Col>
            <Col className="gutter-row" span={12}>
              <Form.Item
                label="Employee Age"
                rules={[{ required: true, message: "Please Enter Age!" }]}
              >
                <Input
                  id="age"
                  value={inputValue.age || ""}
                  onChange={(e) => handlechange(e.target)}
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col className="gutter-row" span={12}>
              <Form.Item
                label="Equalification"
                rules={[
                  { required: true, message: "Please Enter Equalification!" },
                ]}
              >
                <Input
                  id="equalification"
                  value={inputValue.equalification || ""}
                  onChange={(e) => handlechange(e.target)}
                />
              </Form.Item>
            </Col>
            <Col className="gutter-row" span={12}>
              <Form.Item
                label="designation"
                rules={[
                  { required: true, message: "Please Enter Designation!" },
                ]}
              >
                <Input
                  id="designation"
                  value={inputValue.designation || ""}
                  onChange={(e) => handlechange(e.target)}
                />
              </Form.Item>
            </Col>
          </Row>
        </Modal>
      </Flex>
    </div>
  );
}

export default Employee;
