import axios from "axios";
import { toast } from "react-toastify";
import { BASE_URL } from "./Setting";

const getContentType = () => {
  return ({
    headers: {
      "Content-Type": "application/json",
    },
  });
};

export const get = (endpoint: string) => {
  try {
    const value = axios
      .get(`${BASE_URL}${endpoint}`)
      .then((result: any) => result);
    return value;
  } catch (error: any) {
    console.log(error);
    toast("Something went wrong, please Contact Admin");
  }
};
export const post = (endpoint: string, input: any) => {
  try {
    const value = axios
      .post(`${BASE_URL}${endpoint}`, input, getContentType())
      .then((result: any) => result);
    return value;
  } catch (error: any) {
    console.log(error);
    toast("Something went wrong, please Contact Admin");
  }
};
export const put = (endpoint: string, input: any) => {
  try {
    const value = axios
      .put(`${BASE_URL}${endpoint}`, input, getContentType())
      .then((result: any) => result);
    return value;
  } catch (error: any) {
    console.log(error);
    toast("Something went wrong, please Contact Admin");
  }
};
export const deleted = (endpoint: string, input: any) => {
  try {
    const value = axios
      .delete(`${BASE_URL}${endpoint}`, input)
      .then((result: any) => result);
    return value;
  } catch (error: any) {
    console.log(error);
    toast("Something went wrong, please Contact Admin");
  }
};
