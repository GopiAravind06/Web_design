import { useEffect } from "react";
import LayoutMain from "./MasterLayout/LayoutMain";
import { Route, Routes, useNavigate } from "react-router-dom";
import Employee from "./Components/Employee";
import Details from "./Components/Details";
import Login from "./Components/Login";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
function App() {
  const userName = sessionStorage.getItem("username");
  const navigate = useNavigate();

  useEffect(() => {
    if (!userName) {
      navigate("/login");
    }
  }, []);

  return (
    <>
      <Routes>
        <Route path="/login" element={<Login />} />
        {userName && (
          <Route path="/" element={<LayoutMain />}>
            <Route path="/Employee" element={<Employee />} />
            <Route path="/Details" element={<Details />} />
          </Route>
        )}
      </Routes>
    </>
  );
}

export default App;
