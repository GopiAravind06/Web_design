// import { useEffect, useState } from "react";
// import { Button, Col, Form, Modal, Row } from "react-bootstrap";
// import Table from "react-bootstrap/Table";
// import { useDispatch, useSelector } from "react-redux";
// import { deletedTask, selectedTaskValue, updateTask } from "../taskSlice";

// export interface Task {
//   id: number;
//   taskName: string;
//   name: string;
//   email: string;
//   description: string;
// }

// function TaskList() {
//   const dispatch = useDispatch();
//   const { taskList, selectedTask } = useSelector((state: any) => state.task);
//   const [modifiedValue, setModifiedValue] = useState<Task>(selectedTask);
//   const [data, setData] = useState(taskList);
//   const [modalShow, setModalShow] = useState<boolean>(false);

//   const handleRowClick = (obj: Task) => {
//     dispatch(selectedTaskValue(obj));
//   };

//   const updateTaskValue = () => {
//     dispatch(updateTask(modifiedValue));
//   };

//   const handleChange = (e: any) => {
//     const { name, value } = e;
//     setModifiedValue((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };
//   const deletedTaskValue = (value:any) => {
//     dispatch(deletedTask(value));

//   };
//   useEffect(() => {
//       setData(taskList);
//   }, [taskList]);

//   useEffect(() => {
//     if (Object.keys(selectedTask).length > 0) {
//       setModifiedValue(selectedTask);
//     }
//   }, [selectedTask]);

//   return (
//     <>
//       <div className="text-center">
//         <h1>Task Management</h1>
//         <h4 className=""> Total - {data.length}</h4>
//       </div>
//       <div className="container my-13">
//         <Table striped bordered hover>
//           <thead>
//             <tr className="text-center">
//               <th>S.no</th>
//               <th>Name</th>
//               <th>Email</th>
//               <th>Task Name</th>
//               <th>Task Description</th>
//               <th>Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {data.map((obj: any, index: number) => (
//               <tr className="text-center" key={index + 1}>
//                 <td>{index + 1}</td>
//                 <td>{obj.name}</td>
//                 <td>{obj.email}</td>
//                 <td>{obj.taskName}</td>
//                 <td>{obj.description}</td>
//                 <td>
//                   <Button
//                     variant="primary"
//                     className="mx-2"
//                     type="submit"
//                     onClick={() => {
//                       handleRowClick(obj);
//                       setModalShow(true);
//                     }}
//                   >
//                     <i className="bi bi-pencil"></i>
//                   </Button>
//                   <Button variant="primary" type="submit" onClick={() => {deletedTaskValue(obj)}}>
//                     <i className="bi bi-x-lg"></i>
//                   </Button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </Table>
//       </div>
//       <Modal
//         size="lg"
//         aria-labelledby="contained-modal-title-vcenter"
//         show={modalShow}
//         onHide={() => setModalShow(false)}
//         centered
//       >
//         <Modal.Header closeButton>
//           <Modal.Title id="contained-modal-title-vcenter">
//             Update List
//           </Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <div className="container">
//             <Row className="justify-content-center">
//               <Col lg="4">
//                 <Form.Label>Name</Form.Label>
//                 <Form.Control
//                   type="text"
//                   placeholder="Enter Name"
//                   value={modifiedValue.name}
//                   name="name"
//                   onChange={(e) => {
//                     handleChange(e.target);
//                   }}
//                 />
//               </Col>
//               <Col lg="4">
//                 <Form.Label>Email</Form.Label>
//                 <Form.Control
//                   type="email"
//                   placeholder="Enter Email"
//                   value={modifiedValue.email}
//                   name="email"
//                   onChange={(e) => {
//                     handleChange(e.target);
//                   }}
//                 />
//               </Col>
//               <Col lg="4">
//                 <Form.Label>Task Name</Form.Label>
//                 <Form.Control
//                   type="text"
//                   placeholder="Enter Task name"
//                   value={modifiedValue.taskName}
//                   name="taskName"
//                   onChange={(e) => {
//                     handleChange(e.target);
//                   }}
//                 />
//               </Col>
//             </Row>
//             <Row className="justify-content-center">
//               <Col lg="12">
//                 <Form.Label>Description</Form.Label>
//                 <Form.Control
//                   as="textarea"
//                   rows={3}
//                   placeholder="Enter Task Description"
//                   value={modifiedValue.description}
//                   name="description"
//                   onChange={(e) => {
//                     handleChange(e.target);
//                   }}
//                 />
//               </Col>
//             </Row>
//           </div>
//         </Modal.Body>
//         <Modal.Footer>
//           <Button
//             onClick={() => {
//               updateTaskValue();
//               setModalShow(false);
//             }}
//           >
//             Update Task
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </>
//   );
// }

// export default TaskList;

import { useEffect, useState } from "react";
import { Button, Col, Form, Modal, Row } from "react-bootstrap";
import Table from "react-bootstrap/Table";
import { useDispatch, useSelector } from "react-redux";
import { deletedTask, getTaskList, selectedTaskValue, updateTask } from "../taskSlice";
import type { AppDispatch } from "../taskStore";
// import { deletedTask, selectedTaskValue, updateTask , deletedTask} from "../taskSlice";

export interface Task {
  id: number;
  taskName: string;
  name: string;
  email: string;
  description: string;
}

function TaskList() {
  const dispatch = useDispatch<AppDispatch>();
  const { taskList, selectedTask } = useSelector((state: any) => state.task);
  const [modifiedValue, setModifiedValue] = useState<Task>(selectedTask);
  const [data, setData] = useState(taskList);
  const [modalShow, setModalShow] = useState<boolean>(false);

  const handleRowClick = (obj: Task) => {
     dispatch(selectedTaskValue(obj));
  };

  const updateTaskValue = () => {
     dispatch(updateTask(modifiedValue));
  };


  const handleChange = (e: any) => {
    const { name, value } = e;
    setModifiedValue((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const deletedTaskValue = (value:any) => {
    dispatch(deletedTask(value));

  };
  useEffect(() => {
      setData(taskList);
  }, [taskList]);
  useEffect(() => {
      dispatch(getTaskList())
  }, [dispatch]);

  useEffect(() => {
    if ( selectedTask && Object.keys(selectedTask).length > 0) {
      setModifiedValue(selectedTask);
    }
  }, [selectedTask]);

  return (
    <>
      <div className="text-center">
        <h1>Task Management</h1>
        <h4 className=""> Total - {data.length}</h4>
      </div>
      <div className="container my-13">
        <Table striped bordered hover>
          <thead>
            <tr className="text-center">
              <th>S.no</th>
              <th>Name</th>
              <th>Email</th>
              <th>Task Name</th>
              <th>Task Description</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((obj: any, index: number) => (
              <tr className="text-center" key={index + 1}>
                <td>{index + 1}</td>
                <td>{obj.name}</td>
                <td>{obj.email}</td>
                <td>{obj.taskName}</td>
                <td>{obj.description}</td>
                <td>
                  <Button
                    variant="primary"
                    className="mx-2"
                    type="submit"
                    onClick={() => {
                      handleRowClick(obj);
                      setModalShow(true);
                    }}
                  >
                    <i className="bi bi-pencil"></i>
                  </Button>
                  <Button variant="primary" type="submit" onClick={() => {deletedTaskValue(obj)}}>
                    <i className="bi bi-x-lg"></i>
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
      <Modal
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        show={modalShow}
        onHide={() => setModalShow(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Update List
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="container">
            <Row className="justify-content-center">
              <Col lg="4">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Name"
                  value={modifiedValue?.name}
                  name="name"
                  onChange={(e) => {
                    handleChange(e.target);
                  }}
                />
              </Col>
              <Col lg="4">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter Email"
                  value={modifiedValue?.email}
                  name="email"
                  onChange={(e) => {
                    handleChange(e.target);
                  }}
                />
              </Col>
              <Col lg="4">
                <Form.Label>Task Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Task name"
                  value={modifiedValue?.taskName}
                  name="taskName"
                  onChange={(e) => {
                    handleChange(e.target);
                  }}
                />
              </Col>
            </Row>
            <Row className="justify-content-center">
              <Col lg="12">
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  placeholder="Enter Task Description"
                  value={modifiedValue?.description}
                  name="description"
                  onChange={(e) => {
                    handleChange(e.target);
                  }}
                />
              </Col>
            </Row>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button
            onClick={() => {
              updateTaskValue();
              setModalShow(false);
            }}
          >
            Update Task
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default TaskList;

