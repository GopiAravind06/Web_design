import { useMemo, useRef, useState } from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import { useDispatch } from "react-redux";
import { addTask } from "../taskSlice";
// import { addTask } from "../taskSlice";
interface taskValue {
  name: string;
  email: string;
  taskName: string;
  description: string;
}
function Homepage() {
  const exampleRef = useRef(null);
  const [stringValue, setStringValue] = useState("");
  const [mode, setMode] = useState(false);
   const dispatch = useDispatch();
  const [taskValue, setTaskValue] = useState<taskValue>({
    name: "",
    email: "",
    taskName: "",
    description: "",
  });

  const handleChangeValue = (onChangeValue: any) => {
    const { name, value } = onChangeValue;
    setTaskValue((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const handleSave = () => {
     dispatch(addTask(taskValue));
    setTaskValue({
      name: "",
      email: "",
      taskName: "",
      description: "",
    });
  };

  // const getResult = () => {
  //   //const value = [2, 34, 3, 4, 2, 4, 90, 6];

  //   //find the duplicate number
  //   // const result = value.reduce((acc: any, val: any) => {
  //   //   if (!acc.includes(val)) {
  //   //     acc.push(val);
  //   //   }
  //   //    return acc;
  //   // }, []);

  //   // sum of the value
  //   //const result = value.reduce((acc:any, val:any)=> acc + val,0)/

  //   // count the value
  //   // const result = value.reduce((acc: any, val: any) => {
  //   //   acc[val] = (acc[val] || 0) + 1;
  //   //   return acc;
  //   // }, {});

  //   // const arr = [10, 5, 20, 8];
  //   // const maxValue = arr.sort((a,b)=>b-a)

  //   const value = [
  //     { name: "gopi", age: 25, location: "Trichy" },
  //     { name: "Aravind", age: 25, location: "Chennai" },
  //     { name: "Soundar raj", age: 23, location: "Trichy" },
  //     { name: "Sundar", age: 54, location: "Chennai" },
  //     { name: "Hema", age: 49, location: "Chennai" },
  //     { name: "Umesh", age: 24, location: "Chennai" },
  //     { name: "Jamal", age: 25, location: "Madurai" },
  //   ];

  //   // const result = value.reduce((acc: any, val: any) => {
  //   //   if (!acc[val.location]) {
  //   //     acc[val.location] = [];
  //   //   }
  //   //   acc[val.location].push(val)
  //   //   return acc;
  //   // }, {});

  //   const result = value.reduce((acc: any, val: any) => {
  //     if (!acc[val.age]) {
  //       acc[val.age] = [];
  //     }
  //     acc[val.age].push(val);
  //     return acc;
  //   }, {});
  //   //console.log(result);
  // };

//   //==============================================================================================================
//   // 1, Reverse a String (With Built-in Methods)
//   //  const value = "Gopi Araind";
//   //console.log(value.split("").reverse().join(""));

//   // 2, Reverse a String (Without Built-in Methods)
//   const reverseString = (str: string) => {
//     let result = "";
//     for (let i = str.length - 1; i >= 0; i--) {
//       result = result + str[i];
//     }
//     return result;
//   };
//   // console.log(reverseString("javascript"));
//   //==============================================================================================================
//   //3, Palindrome Check
//   const checkPalindrome = (value: string): boolean => {
//     const cleanValue = value.toLowerCase().replace(/\s/g, "");
//     let result = "";
//     for (let i = cleanValue.length - 1; i >= 0; i--) {
//       result += cleanValue[i];
//     }
//     return cleanValue === result;
//   };
//   // console.log(checkPalindrome("A man a plan a canal Panama"));
//   //==============================================================================================================
//   //4, Find Duplicates in Array
//   const findDuplicate = (value: any[]) => {
//     const duplicateValue: any = [];
//     value?.reduce((acc: any, val: any) => {
//       if (!acc.includes(val)) {
//         acc.push(val);
//       } else if (!duplicateValue.includes(val)) {
//         duplicateValue.push(val);
//       }
//       return acc;
//     }, []);
//     return duplicateValue;
//   };
//   //console.log(findDuplicate([1, 1, 2, 3, 3, 3, 4]));
//   //==============================================================================================================
//   //5, Flatten Nested Array
//   const flattenArray = (arr: any) => {
//     let result: any[] = [];
//     for (let item of arr) {
//       if (Array.isArray(item)) {
//         result = result.concat(flattenArray(item));
//       } else {
//         result.push(item);
//       }
//     }
//     return result;
//   };

//   // console.log(flattenArray([1, [2, [3, [4]]]]));
//   //==============================================================================================================
//   // 6, find largest number
//   const findLargest = (arr: any[]) => {
//     const result = arr.sort((a, b) => b - a);
//     return result[0];
//   };
//   // console.log(findLargest([-10, -5, -20, -1]));
//   //==============================================================================================================
//   //7, Count Frequency of Elements
//   const countFrequency = (arr: any) => {
//     const result = arr.reduce((acc: any, val: any) => {
//       if (!acc[val]) {
//         acc[val] = 0;
//       }
//       acc[val] = (acc[val] || 0) + 1;
//       return acc;
//     }, {});
//     return result;
//   };
//   // console.log(countFrequency([1, 1, 1, 2, 3, 3]));
//   //==============================================================================================================
//   //8, Remove Duplicates from Array
//   const removeDuplicates = (arr: any) => {
//     const result = [...new Set(arr)];
//     return result;
//   };
//   // console.log(removeDuplicates([1, 2, 2, 3, 1, 4]));
//   //==============================================================================================================
//   //9, Find Missing Number in Array
//   const findMissing = (arr: any) => {
//     let result = 0;
//     for (let i = 1; i <= arr[arr.length - 1]; i++) {
//       if (!arr.includes(i)) {
//         result = i;
//       }
//     }

//     return result;
//   };
//   //console.log(findMissing([1, 2, 4, 5, 6]));
//   //==============================================================================================================
//   //10. Merge Two Arrays Without Duplicates
//   const mergeArrays = (arr1: any, arr2: any) => {
//     const result = [...new Set([...arr1, ...arr2])];
//     return result;
//   };
//   //console.log(mergeArrays([1, 2, 3], [2, 3, 4]));
//   //==============================================================================================================
//   //11. Group Anagrams
//   const groupAnagrams = (arr: any) => {
//     const result = arr.reduce((acc: any, val: any) => {
//       const correctValue = val.split("").sort().join("");
//       if (!acc[correctValue]) {
//         acc[correctValue] = [];
//       }
//       acc[correctValue].push(val);
//       return acc;
//     }, {});
//     return Object.values(result);
//   };
//   // console.log(groupAnagrams(["abc", "bca", "cab", "xyz", "zyx"]));

//   //==============================================================================================================

//   const checkString = (value: string): boolean => {
//     const setanceValue = value.toLowerCase().replace(/\s/g, "");
//     let openBrace = "";
//     let closeBrace = "";

//     for (let i = 0; i <= setanceValue.length; i++) {
//       if (setanceValue[i] === "{") {
//         openBrace = setanceValue[i];
//       } else if (setanceValue[i] === "}") {
//         closeBrace = setanceValue[i];
//       }
//     }
//     return openBrace !== "" && closeBrace !== "";
//   };

//   //console.log(checkString('{Gopi Aravind}'))

//   //==============================================================================================================

  

//   const value = useMemo(() => {
//     console.log("gopi");
//     if (stringValue) {
//       return reverseFunction(stringValue);
//     }
//     return "";
//   }, [stringValue]);

//   function reverseFunction(val: string) {
//     let result = "";
//     for (let i = val.length - 1; i >= 0; i--) {
//       result += val[i];
//     }
//     return result;
//   }

//   const colour = {
//     background: mode ? "black" : "white",
//     textcolour: mode ? "white" : "black",
//   };
//   //===================================================================================================
//   const reverseValue = (val: string) => {
//     let result = "";
//     for (let i = val.length - 1; i >= 0; i--) {
//       result += val[i];
//     }
//     return result;
//   };
//   const reverseWords = (val: string) => {
//     let words = val.split(" ");
//     let result = [];

//     for (let item of words) {
//       result.push(reverseValue(item));
//     }
//     return result.join(" ");
//   };
//   //console.log(reverseWords("welcome to india"));
//   const reverseSentance = (value: string) => {
//     let words = value.split(" ");
//     let result = [];
//     for (let i = words.length - 1; i >= 0; i--) {
//       result.push(words[i]);
//     }
//     return result.join(" ");
//   };
//   //console.log(reverseSentance('i am a react developer'))
//   //===================================================================================================

// value

  return (
    <div>
      <h1 className="text-center">Task Management</h1>
      <div className="container my-8">
        <Row className="justify-content-center">
          <Col lg="4">
            <Form.Label>Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter Name"
              name="name"
              value={taskValue.name}
              onChange={(e) => {
                handleChangeValue(e.target);
              }}
            />
          </Col>
          <Col lg="4">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter Email"
              name="email"
              value={taskValue.email}
              onChange={(e) => {
                handleChangeValue(e.target);
              }}
            />
          </Col>
          <Col lg="4">
            <Form.Label>Task Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter Task name"
              name="taskName"
              value={taskValue.taskName}
              onChange={(e) => {
                handleChangeValue(e.target);
              }}
            />
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col lg="12">
            <Form.Label>Description</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="description"
              value={taskValue.description}
              onChange={(e) => {
                handleChangeValue(e.target);
              }}
              placeholder="Enter Task Description"
            />
          </Col>
        </Row>
        <div className="my-3 text-end">
          <Button
            variant="primary"
            type="submit"
            onClick={() => {
               handleSave();
              //getResult();
            }}
          >
            Submit
          </Button>
        </div>
      </div>

      {/* <h1
        style={colour}
        onClick={() => {
          setMode(!mode);
          console.log("button");
        }}
      >
        Write, edit and run HTML, CSS and JavaScript code online.
      </h1>
      <button> Mode</button>
      <p id="exampleID" ref={exampleRef}>
        {value}
      </p>
      <input
        type="text"
        placeholder="enter the name"
        style={{ padding: "0px", margin: "20px" }}
        onChange={(e) => setStringValue(e.target?.value)}
      /> */}
    </div>
  );
}

export default Homepage;
