// import { createSlice } from "@reduxjs/toolkit";

import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

// export interface Task {
//   id: number;
//   taskName: string;
//   name: string;
//   email: string;
//   description: string;
// }

// interface TaskState {
//   taskList: Task[];
//   selectedTask: {};
// }

// const initialState: TaskState = {
//   taskList: [],
//   selectedTask: {},
// };

// const taskSlice = createSlice({
//   name: "task",
//   initialState,
//   reducers: {
//     addTask: (state, action) => {
//       const id = Math.random() * 100;
//       const value = { ...action.payload, id };
//       state.taskList.push(value);
//     },
//     selectedTaskValue: (state, action) => {
//       state.selectedTask = action.payload;
//     },
//     updateTask: (state, action) => {
//       state.taskList = state.taskList.map((obj) =>
//         obj.id === action.payload.id ? action.payload : obj,
//       );
//     },
//     deletedTask: (state, action) => {
//       state.taskList = state.taskList.filter(
//         (obj: any) => obj.id !== action.payload.id,
//       );
//     },
//   },
// });

// export const { addTask, selectedTaskValue, updateTask,deletedTask } = taskSlice.actions;
// export default taskSlice.reducer;

const initialState: any = {
  taskList: [],
  selectedTask: {},
  loading: false,
  error: "",
};

// export const getTaskList = createAsyncThunk("get/getTaskList", async () => {
//   const response = await axios.get("http://localhost:8000/task");
//   console.log(response.data)
//   return response.data;

// });
export const getTaskList = createAsyncThunk(
  "get/getTaskList",
  async (_, thunkAPI) => {
    try {
      const response = await axios.get("http://localhost:8000/task");
      return response.data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const taskSlice = createSlice({
  name: "task",
  initialState,
  reducers: {
    addTask: (state, action) => {
      const id = Math.random() * 100;
      const task = { ...action.payload, id };
      state.taskList.push(task);
    },
    selectedTaskValue: (state, action) => {
      state.selectedTask = action.payload;
    },
    updateTask: (state, action) => {
      state.taskList = state.taskList.map((obj: any) => {
        if (obj.id === action.payload.id) {
          return action.payload;
        } else return obj;
      });
    },
    deletedTask: (state, action) => {
      state.taskList = state.taskList.filter(
        (obj: any) => obj.id != action.payload.id,
      );
    },
  },
  extraReducers(builder) {
    builder
      .addCase(getTaskList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getTaskList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = "";
        state.taskList = action.payload;
      })
      .addCase(getTaskList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error;
        state.taskList = [];
      });
  },
});

export const { addTask, selectedTaskValue, updateTask, deletedTask } =
  taskSlice.actions;
export default taskSlice.reducer;
