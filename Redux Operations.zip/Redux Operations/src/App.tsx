import { useState } from 'react'
import './App.css'
import Navbars from './Components/Navbar'

import TaskList from './Components/TaskList';
import { Route, Routes } from 'react-router-dom';
import Homepage from './Components/Homepage';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import "bootstrap-icons/font/bootstrap-icons.css";  

function App() {
  const [count, setCount] = useState(0)
  return (
    <>
    <Navbars/>
    <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/tasklist" element={<TaskList />} />
      </Routes>
    </>
  )
}

export default App
