// import { configureStore } from "@reduxjs/toolkit";
import taskReducer from "./taskSlice";
import { configureStore } from "@reduxjs/toolkit";

// export const store = configureStore({
//     reducer:{
//         task:taskReducer
//     }
// })

export const store = configureStore({
  reducer: {
    task: taskReducer,
  },
});

export type AppDispatch = typeof store.dispatch;
