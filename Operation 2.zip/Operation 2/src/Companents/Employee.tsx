import React, { useState } from "react";
import { Button, Space, Table } from "antd";
import type { TableProps } from "antd";
import { Modal } from "react-bootstrap";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
interface inputValues {
  id: number;
  empName: string;
  age: string;
  phoneNumber: string;
  designation: string;
  qualification: string;
  emailAddress: string;
}

const Employee: React.FC = () => {
  const [modalShow, setModalShow] = useState(false);
  const [data, setData] = useState<inputValues[]>([]);

  const [inputValue, setInputValue] = useState<inputValues>({
    id: 0,
    empName: "",
    age: "",
    phoneNumber: "",
    designation: "",
    qualification: "",
    emailAddress: "",
  });
  const handleChange = (e: any) => {
    const { id, value } = e;
    setInputValue((prev: any) => {
      return {
        ...prev,
        [id]: value,
      };
    });
  };
  const onSave = () => {
    if (inputValue.id === 0) {
      const insertData = {
        id: Math.random() * 100,
        empName: inputValue.empName,
        age: inputValue.age,
        phoneNumber: inputValue.phoneNumber,
        designation: inputValue.designation,
        qualification: inputValue.qualification,
        emailAddress: inputValue.emailAddress,
      };
      setData([...data, insertData]);
      onReset();
      setModalShow(false);
    } else {
      const updateValue = {
        id: inputValue.id,
        empName: inputValue.empName,
        age: inputValue.age,
        phoneNumber: inputValue.phoneNumber,
        designation: inputValue.designation,
        qualification: inputValue.qualification,
        emailAddress: inputValue.emailAddress,
      };
      setData(
        data.map((result: inputValues) =>
          result.id === inputValue.id ? updateValue : result,
        ),
      );
      onReset();
      setModalShow(false);
    }
  };
  const onReset = () => {
    setInputValue({
      id: 0,
      empName: "",
      age: "",
      phoneNumber: "",
      designation: "",
      qualification: "",
      emailAddress: "",
    });
  };
  const handleRowClick = (value: inputValues) => {
    setModalShow(true);
    setInputValue(value);
  };
  const deletedValue = (value: inputValues) => {
    setData(data.filter((result: inputValues) => result.id !== value.id));
  };

  const columns: TableProps<inputValues>["columns"] = [
    {
      title: "Employee Name",
      dataIndex: "empName",
      key: "empName",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Age",
      dataIndex: "age",
      key: "age",
    },
    {
      title: "Email Address",
      dataIndex: "emailAddress",
      key: "emailAddress",
    },
    {
      title: "Designation",
      dataIndex: "designation",
      key: "designation",
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Space size="medium">
          <EditOutlined
            onClick={() => {
             handleRowClick(record);
            }}
          />
          <DeleteOutlined
            onClick={() => {
             deletedValue(record);
            }}
          />
        </Space>
      ),
    },
  ];

  return (
    <>
      <div className="toolbar">
        <h2>Employee Detail</h2>
        <Button
          type="primary"
          onClick={() => {
            setModalShow(true);
          }}
        >
          Add Employee
        </Button>
      </div>
      <div style={{ maxHeight: 100 }}>
        <Table<inputValues>
          columns={columns}
          dataSource={data}
          scroll={{ x: "max-content", y: 300 }}
        />
      </div>
      <Modal
        size="xl"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={modalShow}
        onHide={() => setModalShow(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Employee Details
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="container ">
            <div className="row">
              <div className="col-4">
                <div className="mb-3">
                  <label htmlFor="employeeName" className="form-label">
                    Employee Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="empName"
                    name="empName"
                    placeholder="Enter the employee Name"
                    value={inputValue.empName}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
              </div>
              <div className="col-4">
                <div className="mb-3">
                  <label htmlFor="age" className="form-label">
                    Age
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="age"
                    placeholder="Enter the age"
                    value={inputValue.age}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
              </div>
              <div className="col-4">
                <div className="mb-3">
                  <label htmlFor="education" className="form-label">
                    Qualification
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="qualification"
                    placeholder="Enter the Qualification"
                    value={inputValue.qualification}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-4">
                <div className="mb-3">
                  <label htmlFor="designation" className="form-label">
                    Designation
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="designation"
                    placeholder="Enter Designation"
                    value={inputValue.designation}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
              </div>
              <div className="col-4">
                <div className="mb-3">
                  <label htmlFor="emailAddress" className="form-label">
                    Email address
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    id="emailAddress"
                    placeholder="Enter the Email"
                    value={inputValue.emailAddress}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
              </div>
              <div className="col-4">
                <div className="mb-3">
                  <label htmlFor="phoneNumber" className="form-label">
                    Phone Number
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="phoneNumber"
                    placeholder="Enter the Phone"
                    maxLength={10}
                    value={inputValue.phoneNumber}
                    onChange={(e) => {
                      handleChange(e.target);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button
            type="primary"
            onClick={() => {
               onSave();
            }}
          >
            {" "}
            Save
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
export default Employee;
