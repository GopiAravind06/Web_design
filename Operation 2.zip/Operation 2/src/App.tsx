import { Route, Routes } from "react-router-dom";
import "./App.css";
import MainLayout from "./Layout/MainLayout";
import Dashboard from "./Companents/Dashboard";
import Employee from "./Companents/Employee";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"

function App() {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="/Dashboard" element={<Dashboard />} />
        <Route path="/Employee" element={<Employee />} />
      </Route>
    </Routes>
  );
}

export default App;
